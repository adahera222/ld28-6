Copyright 2013 Kenneth Austin

Built for Ludum Dare #28 (Jam)

If you get stuck press H for help.
If you get really stuck, try right clicking .
(You didn't hear it from me!)

If you like the game, please consider Greenlighting 
it on Steam via the link below.

http://steamcommunity.com/sharedfiles/filedetails/?id=204635252

Enjoy!